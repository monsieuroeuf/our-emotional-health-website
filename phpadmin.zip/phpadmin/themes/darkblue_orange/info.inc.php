<?php
/* $Id: info.inc.php,v 2.0 2004/10/13 10:02:44 rabus Exp $ */
/* Theme information */
$theme_name = 'Darkblue/orange';
$theme_version = 1;
$theme_generation = 1;
?>
