<?php
/*
  Created by: Linda McGrath osCOMMERCE@WebMakers.com
  
  Update by: fram 05-05-2003

  down_for_maintenance.php v1.1
  
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Down for Maintenance');
define('HEADING_TITLE', 'Site Down for Maintenance ...');
define('DOWN_FOR_MAINTENANCE_TEXT_INFORMATION', '<b>The site is currently down for maintenance. We apologize
		For any inconvenience caused by this outage.
		Please try again later.<b>');
define('TEXT_MAINTENANCE_ON_AT_TIME', 'The Admin / Webmaster has enabled maintenance at : ');
define('TEXT_MAINTENANCE_PERIOD', 'Maintenance period : ');
define('DOWN_FOR_MAINTENANCE_STATUS_TEXT', 'To verify the site status ... Click here:');
?>