*********************************************************************
*                                                                   *
*              3D Silver Buttons For OSCOMMERCE                     *
*                                                                   *
*********************************************************************

------[ CONTRIBUTED BY E-LOGO DEVELOPMENTS - www.elogo.co.nz ]------
------[               Transparency by Mahoo		     ]------


This button zip file includes total button replacement for OSCOMMERCE

The buttons have been tested on OSC vers.2.2 snapshot 16 APRIL 2004


[x]------------- INSTALL -------------[x]

Unzip files to your computer in a temp directory.

Upload via ftp in the directory below, make sure when prompted you select
to overwrite existing images.

...Gatalog/Includes/Languages/English/Images/Buttons/

Your Done!

Make sure you refresh your browser to view your nice new buttons!

