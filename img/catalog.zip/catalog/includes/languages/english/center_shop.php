<?php
// WebMakers.com Added: CENTER SHOP CONTROL
// /catalog/includes/languages/english/center_shop.php
// in english.php require(DIR_WS_LANGUAGES . $language . '/' . 'center_shop.php');

$iQuery1 = " SELECT * FROM ". TABLE_CONFIGURATION . " WHERE configuration_id = 445 ";  //CENTER_SHOP_ON
$config1 = tep_db_query($iQuery1);
$r1 = mysql_fetch_row ($config1);
$isOn = $r1['3'];

$iQuery2 = " SELECT * FROM ". TABLE_CONFIGURATION . " WHERE configuration_id = 446 "; //CENTER_SHOP_ALIGN
$config2 = tep_db_query($iQuery2);
$r2 = mysql_fetch_row ($config2);
$iAlign = $r2['3'];

$iQuery3 = " SELECT * FROM ". TABLE_CONFIGURATION . " WHERE configuration_id = 447 "; //CENTER_SHOP_WIDTH
$config3 = tep_db_query($iQuery3);
$r3 = mysql_fetch_row ($config3);
$iWidth  = $r3['3'];

define('CENTER_SHOP_ON',$isOn); 

if (CENTER_SHOP_ON == '0'){
	define('CENTER_SHOP_WIDTH','100%');
	define('CENTER_SHOP_ALIGN','center');
} else {
	define('CENTER_SHOP_WIDTH',$iWidth); 
	define('CENTER_SHOP_ALIGN',$iAlign);
}
?>
