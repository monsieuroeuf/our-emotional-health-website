<?php
/*
  $Id: shipping.php,v 1.4 2002/11/19 01:48:08 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

$iQuery = " SELECT info_contents_shipping_text FROM ". TABLE_INFO_CONTENTS . " WHERE info_contents_id = 1 "; 
$shipping = $db->get_row($iQuery);
$shipping_text = $shipping->info_contents_shipping_text;
$shipping_text = stripslashes($shipping_text);

define('NAVBAR_TITLE', 'Shipping & Returns');
define('HEADING_TITLE', 'Shipping & Returns');
define('DEVELOPER_COMPANY', STORE_NAME);
define('DEVELOPER_URL', HTTP_SERVER);
define('STORE_LOCATION', 'Western Australia');

define('TEXT_INFORMATION', $shipping_text);
?>