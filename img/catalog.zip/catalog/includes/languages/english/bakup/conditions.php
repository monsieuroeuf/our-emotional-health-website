<?php
/*
  $Id: conditions.php,v 1.3 2001/12/20 14:14:14 dgw_ Exp $

  The Exchange Project - Community Made Shopping!
  http://www.theexchangeproject.org

  Copyright (c) 2000,2001 The Exchange Project

  Released under the GNU General Public License
*/

$iQuery = " SELECT info_contents_conditions_text FROM ". TABLE_INFO_CONTENTS . " WHERE info_contents_id = 1 "; 
$conditions = $db->get_row($iQuery);
$conditions_text = $conditions->info_contents_conditions_text;
$conditions_text = stripslashes($conditions_text);

define('NAVBAR_TITLE', 'Conditions of Use');
define('HEADING_TITLE', 'Conditions of Use');
define('DEVELOPER_COMPANY', STORE_NAME);
define('DEVELOPER_URL', HTTP_SERVER);
define('STORE_LOCATION', 'Western Australia');

define('TEXT_INFORMATION', $conditions_text);
?>