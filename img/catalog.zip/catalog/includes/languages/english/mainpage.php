<?
// Mainpage Text is dynamic. Obtained from osc_tbl_mainpge in database

$iQuery = " SELECT mainpage_text FROM ". TABLE_MAINPAGE . " WHERE mainpage_id = 1 "; 
$mainpage = $db->get_row($iQuery);
$mainpage_text = $mainpage->mainpage_text;
echo stripslashes($mainpage_text);
?>