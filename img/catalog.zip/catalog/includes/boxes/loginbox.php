<?php
/*

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License

  IMPORTANT NOTE:

  This script is not part of the official osC distribution
  but an add-on contributed to the osC community. Please
  read the README and  INSTALL documents that are provided 
  with this file for further information and installation notes.

  loginbox.php -   Version 1.0
  This puts a login request in a box with a login button.
  If already logged in, will not show anything.
  

*/

?>
<!-- loginbox //-->
          <tr>
            <td>
<?
    if (!tep_session_is_registered('customer_id')) {
			    $info_box_contents = array();
			    $info_box_contents[] = array('align' => 'left',
			                                 'text'  => BOX_LOGINBOX_HEADING
			                                );
			    new infoBoxHeading($info_box_contents, false, false);
			    $loginboxcontent = "
			            	<table border='0' width='100%' cellspacing='0' cellpadding='0'>" . 
							tep_draw_form('login', tep_href_link(FILENAME_LOGIN, 'action=process', 'SSL')) . 
							"
			            		    <tr>
			                			<td align='left' class='main'>
			                  				" . BOX_LOGINBOX_EMAIL . "
			                			</td>
						            </tr>
						            <tr>
						                <td align='left' class='main'>
						                  <input type='text' name='email_address' maxlength='96' size='15' value=''>
						                </td>
						            </tr>
						            <tr>
						                <td align='left' class='main'>
						                  " . BOX_LOGINBOX_PASSWORD . "
						                </td>
						            </tr>
						            <tr>
						                <td align='left' class='main'>
						                  <input type='password' name='password' maxlength='40' size='15' value=''
						                </td>
						            </tr>
						            <tr>
						                <td class='main' align='center'>
						                  " . tep_image_submit('button_login.gif', IMAGE_BUTTON_LOGIN) . "
						                </td>
						            </tr>
									<tr><td class='main' align='center'><a href='" . tep_href_link(FILENAME_CREATE_ACCOUNT, '', 'SSL') . "'>"
									 . HEADER_TITLE_CREATE_ACCOUNT . "</a>
									</td></tr>
			            		</form>
			            	</table>
			              ";
			    $info_box_contents = array();
			    $info_box_contents[] = array('align' => 'center',
			                                 'text'  => $loginboxcontent
			                                );
			    new infoBox($info_box_contents);
?>
			
<?
	} else {
		$info_box_contents = array();
		$info_box_contents[] = array('align' => 'left',
		                                 'text'  => BOX_LOGINBOX_HEADING
		                                );
		new infoBoxHeading($info_box_contents, false, false);
	    $loginboxcontent = "
           	<table border='0' width='100%' cellspacing='0' cellpadding='0'>
				<tr>
					<td class='smalltext'> You are logged in. </td>
				</tr>";
				if (tep_session_is_registered('customer_id')) {
					$loginboxcontent .= " 
						<tr>
							<td class='smallText' align='center'><a href='". tep_href_link(FILENAME_LOGOFF, '', 'SSL')."'>"
								. HEADER_TITLE_LOGOFF ." </a></td>
						</tr>";
				}
		$loginboxcontent .=" 
           	</table>
	              ";
		$info_box_contents = array();
	    $info_box_contents[] = array('align' => 'center',
	                                 'text'  => $loginboxcontent
	                                );
		new infoBox($info_box_contents);
	}
	
?>
			</td>
		</tr>
<!-- loginbox_eof //-->