<?php
/* ------------------------------------------------

  coolMenu for osCommerce
  
  author:	Andreas Kothe 
  url:		http://www.oddbyte.de


  Released under the GNU General Public License
  
  ------------------------------------------------ 
*/

?>
<!-- coolMenu //-->

<!-- copyright 2003 Andreas Kothe - www.oddbyte.de // -->

	  <TR>
	    <TD>

<?php
  $info_box_contents = array();
  $info_box_contents[] = array('align' => 'left',
			       'text'  => BOX_HEADING_CATEGORIES
			      );
  new infoBoxHeading($info_box_contents, false,false);

  $info_box_contents = array();
  if (MAX_MANUFACTURERS_LIST < 2) {
	$cat_choose = array(array('id' => '', 'text' => BOX_CATEGORIES_CHOOSE));
  } else {
	$cat_choose = '';
  }



  $info_box_contents[] = array('text'  => '
	<img src="images/trans.gif" width="150" height="' . $height . '">');


  new infoBox($info_box_contents);

?>
	    </TD>
	  </TR>

<!-- coolMenu_eof //-->
