<?php
/*
  $Id: footer.php,v 1.26 2003/02/10 22:30:54 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

  require(DIR_WS_INCLUDES . 'counter.php');
 
  $shopWidth = CENTER_SHOP_WIDTH;
  
  if (CENTER_SHOP_ALIGN !=center){ //adds the offset so that the tables align
	$shopWidth = CENTER_SHOP_WIDTH+15;
  }
  if (CENTER_SHOP_ALIGN !=center){ //stops the tag from adding in additional lines
?>
	<br clear="<?=CENTER_SHOP_ALIGN?>">
<?
  }
?>
 
<table border="0" width="<?=$shopWidth?>" cellspacing="0" cellpadding="2" align="<?=CENTER_SHOP_ALIGN?>">
  <tr class="footer">
    <td class="footer">&nbsp;&nbsp;<?php echo strftime(DATE_FORMAT_LONG); ?>&nbsp;&nbsp;</td>
    <td align="right" class="footer">&nbsp;&nbsp;<?php echo $counter_now . ' ' . FOOTER_TEXT_REQUESTS_SINCE . ' ' . $counter_startdate_formatted; ?>&nbsp;&nbsp;</td>
  </tr>
</table>
<br>
<table border="0" width="<?=$shopWidth?>" cellspacing="0" cellpadding="3" align="<?=CENTER_SHOP_ALIGN?>">
  <tr>
    <td align="center" class="smallText">
<?
/*
  The following copyright announcement can only be
  appropriately modified or removed if the layout of
  the site theme has been modified to distinguish
  itself from the default osCommerce-copyrighted
  theme.

  For more information please read the following
  Frequently Asked Questions entry on the osCommerce
  support site:

  http://www.oscommerce.com/community.php/faq,26/q,50

  Please leave this comment intact together with the
  following copyright announcement.
*/
echo FOOTER_TEXT_BODY
?>
    </td>
  </tr>
</table>
<? if ($banner = tep_banner_exists('dynamic', '468x50')) { ?>
<table border="0" width="<?=$shopWidth?>" cellspacing="0" cellpadding="0" align="<?=CENTER_SHOP_ALIGN?>" valign="middle">
  <tr>
	<td align="center"><?php echo tep_display_banner('static', $banner); ?></td>
  </tr>
</table>
<?
	}
?>