<?php
/*
  $Id: database_tables.php,v 1.1 2003/03/14 02:10:58 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

// define the database table names used in the project
  define('TABLE_ADDRESS_BOOK', 'osc_address_book');
  define('TABLE_ADDRESS_FORMAT', 'osc_address_format');
  define('TABLE_BANNERS', 'osc_banners');
  define('TABLE_BANNERS_HISTORY', 'osc_banners_history');
  define('TABLE_CATEGORIES', 'osc_categories');
  define('TABLE_CATEGORIES_DESCRIPTION', 'osc_categories_description');
  define('TABLE_CONFIGURATION', 'osc_configuration');
  define('TABLE_CONFIGURATION_GROUP', 'osc_configuration_group');
  define('TABLE_COUNTER', 'osc_counter');
  define('TABLE_COUNTER_HISTORY', 'osc_counter_history');
  define('TABLE_COUNTRIES', 'osc_countries');
  define('TABLE_CURRENCIES', 'osc_currencies');
  define('TABLE_CUSTOMERS', 'osc_customers');
  define('TABLE_CUSTOMERS_BASKET', 'osc_customers_basket');
  define('TABLE_CUSTOMERS_BASKET_ATTRIBUTES', 'osc_customers_basket_attributes');
  define('TABLE_CUSTOMERS_INFO', 'osc_customers_info');
  define('TABLE_LANGUAGES', 'osc_languages');
  define('TABLE_MANUFACTURERS', 'osc_manufacturers');
  define('TABLE_MANUFACTURERS_INFO', 'osc_manufacturers_info');
  define('TABLE_ORDERS', 'osc_orders');
  define('TABLE_ORDERS_PRODUCTS', 'osc_orders_products');
  define('TABLE_ORDERS_PRODUCTS_ATTRIBUTES', 'osc_orders_products_attributes');
  define('TABLE_ORDERS_PRODUCTS_DOWNLOAD', 'osc_orders_products_download');
  define('TABLE_ORDERS_STATUS', 'osc_orders_status');
  define('TABLE_ORDERS_STATUS_HISTORY', 'osc_orders_status_history');
  define('TABLE_ORDERS_TOTAL', 'osc_orders_total');
  define('TABLE_PRODUCTS', 'osc_products');
  define('TABLE_PRODUCTS_ATTRIBUTES', 'osc_products_attributes');
  define('TABLE_PRODUCTS_ATTRIBUTES_DOWNLOAD', 'osc_products_attributes_download');
  define('TABLE_PRODUCTS_DESCRIPTION', 'osc_products_description');
  define('TABLE_PRODUCTS_NOTIFICATIONS', 'osc_products_notifications');
  define('TABLE_PRODUCTS_OPTIONS', 'osc_products_options');
  define('TABLE_PRODUCTS_OPTIONS_VALUES', 'osc_products_options_values');
  define('TABLE_PRODUCTS_OPTIONS_VALUES_TO_PRODUCTS_OPTIONS', 'osc_products_options_values_to_products_options');
  define('TABLE_PRODUCTS_TO_CATEGORIES', 'osc_products_to_categories');
  define('TABLE_REVIEWS', 'osc_reviews');
  define('TABLE_REVIEWS_DESCRIPTION', 'osc_reviews_description');
  define('TABLE_SESSIONS', 'osc_sessions');
  define('TABLE_SPECIALS', 'osc_specials');
  define('TABLE_TAX_CLASS', 'osc_tax_class');
  define('TABLE_TAX_RATES', 'osc_tax_rates');
  define('TABLE_GEO_ZONES', 'osc_geo_zones');
  define('TABLE_ZONES_TO_GEO_ZONES', 'osc_zones_to_geo_zones');
  define('TABLE_WHOS_ONLINE', 'osc_whos_online');
  define('TABLE_ZONES', 'osc_zones');
  define('TABLE_CSS_CONFIG', 'osc_tbl_css_config');
  define('TABLE_CAMTECH_ERROR', 'osc_tbl_camtech_error'); 
  define('TABLE_CAMTECH_SUCCESS', 'osc_tbl_camtech_success');
  define('TABLE_MAINPAGE','osc_tbl_mainpage');
  define('TABLE_PENDING_FUNCTIONS','osc_tbl_pending_functions');
  define('TABLE_INFO_CONTENTS','osc_tbl_info_contents');
  define('TABLE_URCHIN_LOG','osc_tbl_urchin_log');
?>