<?php
/*
  $Id: column_left.php,v 1.13 2002/06/16 22:08:05 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/
// WebMakers.com Changes: Column Controller v1.0
// Turn on/off column right and individulal boxes
// NOTE: $_SERVER['PHP_SELF'] is used on new items for future updates. Old items still use $PHP_SELF based on current oscommerce code
if (COLUMN_LEFT_IS_ON=='true') {

// BOF: CATAGORIES
  if (BOX_CATAGORIES_IS_ON=='true' and BOX_CATAGORIES_COLUMN=='left') {
  if ((USE_CACHE == 'true') && empty($SID)) {
     echo tep_cache_categories_box();
   } else {
      if ( DISPLAY_DHTML_MENU == 'Dhtml' ) {
       include(DIR_WS_BOXES . 'categories_dhtml.php');
   } elseif (DISPLAY_DHTML_MENU == 'CoolMenu') {
 	  include(DIR_WS_BOXES . 'coolmenu.php');
   } else {
 	  include(DIR_WS_BOXES . 'categories.php');
 	  }
   }
  }
// EOF: CATAGORIES

// BOF: MANUFACTURERS
  if (BOX_MANUFACTURERS_IS_ON=='true' and BOX_MANUFACTURERS_COLUMN=='left') {
  if ( (USE_CACHE == 'true') && !SID) {
    echo tep_cache_manufacturers_box();
  } else {
    include(DIR_WS_BOXES . 'manufacturers.php');
  }
  }
// EOF: MANUFACTURERS

// BOF: BANNER_LEFT
  if (BOX_BANNER_LEFT_IS_ON=='true' and BOX_BANNER_LEFT_COLUMN=='left') {
    if ($banner = tep_banner_exists('dynamic', BANNER_LEFT_GROUP_IS)) {
    ?>
    <tr>
       <td align="center">
    <?php echo tep_display_banner('static', $banner); ?>
       </td>
    </tr>
    <?php
    }
  }
// EOF: BANNER_LEFT

// BOF: WHATS_NEW
  if (BOX_WHATS_NEW_IS_ON=='true' and BOX_WHATS_NEW_COLUMN=='left') {
    require(DIR_WS_BOXES . 'whats_new.php');
  }
// EOF: WHATS_NEW

// BOF: SEARCH
  if (BOX_SEARCH_IS_ON=='true' and BOX_SEARCH_COLUMN=='left') {
    require(DIR_WS_BOXES . 'search.php');
  }
// EOF: SEARCH

// BOF: INFORMATION
  if (BOX_INFORMATION_IS_ON=='true' and BOX_INFORMATION_COLUMN=='left') {
  require(DIR_WS_BOXES . 'information.php');
  }
// EOF: INFORMATION

// BOF: PAY_PAL_LOGO_ON
  if (BOX_PAY_PAL_LOGO_IS_ON=='true' and BOX_INFORMATION_COLUMN=='left') {
    require(DIR_WS_BOXES . 'paypal_logo_on.php');
  }
// EOF: PAY_PAL_LOGO_ON

//
// WebMakers.com Changes: RIGHT_IS_ON_LEFT
//

// BOF: SHOPPING_CART
  if (BOX_SHOPPING_CART_IS_ON=='true' and (COLUMN_RIGHT_IS_ON_LEFT=='left' or BOX_SHOPPING_CART_COLUMN=='left')) {
    require(DIR_WS_BOXES . 'shopping_cart.php');
  }
// EOF: SHOPPING_CART

// BOF: LOGINBOX
  if (BOX_LOGINBOX_IS_ON=='true' and (COLUMN_RIGHT_IS_ON_LEFT=='left' or BOX_LOGINBOX_COLUMN=='left')) {
    if ( (!strstr($_SERVER['PHP_SELF'],'login.php')) and (!strstr($_SERVER['PHP_SELF'],'create_account.php')) )  {
      // WebMakers.com Added: Show if not on a login screen
      // loginbox.php -   Version 1.0
      require(DIR_WS_BOXES . 'loginbox.php');
    }
  }
// EOF: LOGINBOX

// BOF: BANNER_RIGHT
  if (BOX_BANNER_RIGHT_IS_ON=='true' and (COLUMN_RIGHT_COLUMN=='left' or BOX_BANNER_RIGHT_COLUMN=='left' or BOX_BANNER_RIGHT_COLUMN=='both')) {
    if ($banner = tep_banner_exists('dynamic', BANNER_RIGHT_GROUP_IS)) {
    ?>
    <tr>
       <td align="center">
    <?php echo tep_display_banner('static', $banner); ?>
       </td>
    </tr>
    <?php
    }
  }
// EOF: BANNER_RIGHT

// BOF: MANUFACTURER_INFO
  if (BOX_MANUFACTURER_INFO_IS_ON=='true' and (COLUMN_RIGHT_COLUMN=='left' or BOX_MANUFACTURER_INFO_COLUMN=='left')) {
    if ($HTTP_GET_VARS['products_id'])  include(DIR_WS_BOXES . 'manufacturer_info.php');
  }
// EOF: MANUFACTURER_INFO

// BOF: ORDER_HISTORY
  if (BOX_ORDER_HISTORY_IS_ON=='true' and (COLUMN_RIGHT_COLUMN=='left' or BOX_ORDER_HISTORY_COLUMN=='left')) {
    if (tep_session_is_registered('customer_id')) include(DIR_WS_BOXES . 'order_history.php');
  }
// EOF: ORDER_HISTORY

// BOF: BEST_SELLERS and PRODUCT_NOTIFICATIONS
  if ($HTTP_GET_VARS['products_id']) {
    if (session_is_registered('customer_id')) {
      $check_query = tep_db_query("select count(*) as count from " . TABLE_CUSTOMERS_INFO . " where customers_info_id = '" . $customer_id . "' and global_product_notifications = '1'");
      $check = tep_db_fetch_array($check_query);
      if ($check['count'] > 0) {
        if (BOX_BEST_SELLERS_IS_ON=='true' and (COLUMN_RIGHT_COLUMN=='left' or BOX_BEST_SELLERS_COLUMN=='left')) {
          include(DIR_WS_BOXES . 'best_sellers.php');
        }
      } else {
        if (BOX_PRODUCT_NOTIFICATIONS_IS_ON=='true' and (COLUMN_RIGHT_IS_ON_LEFT=='true' or BOX_PRODUCT_NOTIFICATIONS_COLUMN=='left')) {
          include(DIR_WS_BOXES . 'product_notifications.php');
        }
      }
    } else {
      if (BOX_PRODUCT_NOTIFICATIONS_IS_ON=='true' and (COLUMN_RIGHT_IS_ON_LEFT=='true' or BOX_PRODUCT_NOTIFICATIONS_COLUMN=='left')) {
        include(DIR_WS_BOXES . 'product_notifications.php');
      }
    }
  } else {
    if (BOX_BEST_SELLERS_IS_ON=='true' and (COLUMN_RIGHT_IS_ON_LEFT=='true' or BOX_BEST_SELLERS_COLUMN=='left')) {
      include(DIR_WS_BOXES . 'best_sellers.php');
    }
  }
// EOF: BEST_SELLERS and PRODUCT_NOTIFICATIONS

// BOF: TELL_A_FRIEND AND SPECIALS
  if ($HTTP_GET_VARS['products_id']) {
    if (basename($PHP_SELF) != FILENAME_TELL_A_FRIEND and (BOX_TELL_A_FRIEND_IS_ON=='true' and (COLUMN_RIGHT_IS_ON_LEFT=='true' or BOX_TELL_A_FRIEND_COLUMN=='left'))) include(DIR_WS_BOXES . 'tell_a_friend.php');
  } else {
    if (BOX_SPECIALS_IS_ON=='true' and (COLUMN_RIGHT_IS_ON_LEFT=='true' or BOX_SPECIALS_COLUMN=='left')) {
      include(DIR_WS_BOXES . 'specials.php');
    }
  }
// EOF: TELL_A_FRIEND AND SPECIALS

// BOF: REVIEWS
  if (BOX_REVIEWS_IS_ON=='true' and (COLUMN_RIGHT_IS_ON_LEFT=='true' or BOX_REVIEWS_COLUMN=='left')) {
    require(DIR_WS_BOXES . 'reviews.php');
  }
// EOF: REVIEWS

// BOF: LANGUAGES AND CURRENCIES
  if (substr(basename($PHP_SELF), 0, 8) != 'checkout') {
    if (BOX_LANGUAGES_IS_ON=='true' and (COLUMN_RIGHT_IS_ON_LEFT=='true' or BOX_LANGUAGES_COLUMN=='left')) {
      include(DIR_WS_BOXES . 'languages.php');
    }
    if (BOX_CURRENCIES_IS_ON=='true' and (COLUMN_RIGHT_IS_ON_LEFT=='true' or BOX_CURRENCIES_COLUMN=='left')) {
      include(DIR_WS_BOXES . 'currencies.php');
    }
  }
// EOF: LANGUAGES AND CURRENCIES

//
// EOF: WebMakers.com Changes: Column Controller v1.0
//
}
?>