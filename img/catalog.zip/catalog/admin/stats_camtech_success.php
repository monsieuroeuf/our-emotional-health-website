<?php
/*
Camtech error reports
Bobby Patel
03/11/2003
*/
  require('includes/application_top.php');

  require(DIR_WS_CLASSES . 'currencies.php');
  $currencies = new currencies();


?>
<!doctype html public "-//W3C//DTD HTML 4.01 Transitional//EN">
<html <?php echo HTML_PARAMS; ?>>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo CHARSET; ?>">
<title><?php echo TITLE; ?></title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
<script language="javascript" src="includes/general.js"></script>
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<?php
// printer-friendly version
($HTTP_GET_VARS['print']=='yes') ? $print=true : $print=false;
?>
<!-- header //-->
<?php if(!$print) require(DIR_WS_INCLUDES . 'header.php'); ?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="2" cellpadding="2">
  <tr>
	<td width="<?php echo BOX_WIDTH; ?>" valign="top"><table border="0" width="<?php echo BOX_WIDTH; ?>" cellspacing="1" cellpadding="1" class="columnLeft">
	<!-- left_navigation //-->
	<?php require(DIR_WS_INCLUDES . 'column_left.php'); ?>
	<!-- left_navigation_eof //-->
</table>
</td>
<!-- body_text //-->
	<td width="100%" valign="top">
		<table border="0" width="100%" cellspacing="0" cellpadding="2">
      		<tr>
        		<td><table border="0" width="100%" cellspacing="0" cellpadding="0">
			</tr>
          	<tr>
            	<td class="pageHeading"><?php echo HEADING_TITLE; ?></td>
            	<td class="pageHeading" align="right"><?php echo tep_draw_separator('pixel_trans.gif', HEADING_IMAGE_WIDTH, HEADING_IMAGE_HEIGHT); ?></td>
          	</tr>
        </table>
		 </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="2">
              <tr class="dataTableHeadingRow">
			 	<td class="dataTableHeadingContent" align="left"><?php echo TABLE_HEADING_ROWS; ?></td>
                <td class="dataTableHeadingContent"><?php echo TABLE_HEADING_ORDER_NUMBER; ?></td>
                <td class="dataTableHeadingContent" align="right"><?php echo TABLE_HEADING_DATE; ?>&nbsp;</td>
				<td class="dataTableHeadingContent" align="right"><?php echo TABLE_HEADING_AMOUNT; ?>&nbsp;</td>
				<td class="dataTableHeadingContent" align="right"><?php echo TABLE_HEADING_NAME; ?>&nbsp;</td>
              </tr>
<?php
  if (isset($HTTP_GET_VARS['page']) && ($HTTP_GET_VARS['page'] > 1)) $rows = $HTTP_GET_VARS['page'] * MAX_DISPLAY_SEARCH_RESULTS - MAX_DISPLAY_SEARCH_RESULTS;
  $camtech_success_query_raw = "select * from ". TABLE_CAMTECH_SUCCESS;
  $camtech_success_split = new splitPageResults($HTTP_GET_VARS['page'], MAX_DISPLAY_SEARCH_RESULTS, $camtech_success_query_raw, $camtech_success_query_numrows);
// fix counted errors
  $camtech_success_query_numrows = tep_db_query("select * from ". TABLE_CAMTECH_SUCCESS);
  $camtech_success_query_numrows = tep_db_num_rows($camtech_success_query_numrows);
 $rows=0;
  If ($_GET['page'] && $_GET['page'] > 1) {
  	$rows = $rows  + (MAX_DISPLAY_SEARCH_RESULTS* ($_GET['page']-1));
  }
  $camtech_success_query = tep_db_query($camtech_success_query_raw);
  while ($camtech_success = tep_db_fetch_array($camtech_success_query)) {
    $rows++;

    if (strlen($rows) < 2) {
      $rows = '0' . $rows;
    }
?>
              <tr class="dataTableRow" onmouseover="rowOverEffect(this)" onmouseout="rowOutEffect(this)" onclick="document.location.href='<?php echo tep_href_link(FILENAME_STATS_CAMTECH_DETAILS, 'id=' . $camtech_success['camtech_success_id'].'&type=success', 'NONSSL'); ?>'">
				<td class="dataTableContent" align="left"><?php echo $rows; ?>.</td>
                <td class="dataTableContent"><?php echo $camtech_success['camtech_success_ordernumber']; ?></td>
				<td class="dataTableContent" align="right"><?php echo date("j/n/y",strtotime($camtech_success['camtech_success_date'])); ?></td>
				<td class="dataTableContent" align="right"><?php echo "$".($camtech_success['camtech_success_amount']/100); ?></td>
				<td class="dataTableContent" align="right"><?php echo $camtech_success['camtech_success_name']; ?></td>
              </tr>
<?php
  }
?>
	</table></td>
          </tr>
          <tr>
            <td colspan="3"><table border="0" width="100%" cellspacing="0" cellpadding="2">
              <tr>
                <td class="smallText" valign="top"><?php echo $camtech_success_split->display_count($camtech_success_query_numrows, MAX_DISPLAY_SEARCH_RESULTS, $HTTP_GET_VARS['page'],TEXT_DISPLAY_NUMBER_OF_CAMTECH_SUCCESS); ?></td>
                <td class="smallText" align="right"><?php echo $camtech_success_split->display_links($camtech_success_query_numrows, MAX_DISPLAY_SEARCH_RESULTS, MAX_DISPLAY_PAGE_LINKS, $HTTP_GET_VARS['page']); ?>&nbsp;</td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
<!-- body_text_eof //-->
  </tr>
</table>
<!-- body_eof //-->
<!-- footer //-->
<?php require(DIR_WS_INCLUDES . 'footer.php'); ?>
<!-- footer_eof //-->
</body>
</html>
<?php require(DIR_WS_INCLUDES . 'application_bottom.php'); 
?>