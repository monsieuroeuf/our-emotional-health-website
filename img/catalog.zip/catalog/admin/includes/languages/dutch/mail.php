<?php
/*
$Id: mail.php,v 1.8 2002/01/18 17:28:53 hpdl Exp $

osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com

Copyright (c) 2002 Pruts0r

Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Zenden van e-mail naar klanten');

define('TEXT_CUSTOMER', 'Klant:');
define('TEXT_SUBJECT', 'Onderwerp:');
define('TEXT_FROM', 'Van:');
define('TEXT_MESSAGE', 'Bericht:');
define('TEXT_SELECT_CUSTOMER', 'Selecteer klant');
define('TEXT_ALL_CUSTOMERS', 'Alle klanten');
define('TEXT_NEWSLETTER_CUSTOMERS', 'Naar alle nieuwsbriefontvangers');
define('TEXT_EMAIL_BUTTON_TEXT', '<p><HR><b><font color="red">De TERUG Button is uitgeschakeld omdat de HTML WYSIWG Editor op ON staat,</b></font> Waarom ? - Omdat als je op de TERUG KNOP klikt om html te bewerken, de PHP(php.ini)"Magic Quotes = On" automatisch "\\\\\\\" backslashes toevoegd overal waar een " verschijnt (HTML gebruikt dit in links, plaatjes en meer) en dit verstoord de HTML code en de plaatjes zullen verdwijnen als u nog een keer op de verzend knop drukt, Als u de WYSIWYG Editor op OFF zet in de Admin dan zal de HTML mogenlijkheid van Oscommerce ook uitgeschakeld zijn en zal de TERUG BUTTON weer verschijnen.<br><br><b>Als u een preview wilt zien voor u verzend, gebruik dan de Preview knop van WYSIWYG Editor.<br><HR>');
define('TEXT_EMAIL_BUTTON_HTML', '<p><HR><b><font color="red">HTML is uitgeschakeld!</b></font><br><br>Als u HTML email wilt versturen, verander dit dan in: Admin-->Configuration-->WYSIWYG Editor-->Options<br>');
define('NOTICE_EMAIL_SENT_TO', 'E-mail verzonden naar: %s');
define('ERROR_NO_CUSTOMER_SELECTED', 'FOUT: Er zijn geen klanten geselecteerd.');
?>
