<?php
/*
  $Id: stats_products_viewed.php,v 1.5 2003/07/06 20:33:02 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Productos Mas Vistos');

define('TABLE_HEADING_NUMBER', 'N&uacute;mero');
define('TABLE_HEADING_PRODUCTS', 'Productos');
define('TABLE_HEADING_VIEWED', 'Visto');
?>