<?php
/*
  $Id: stats_monthly_sales.php,v 1.5a $
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com
  Copyright (c) 2002 osCommerce
  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Camtech :: Success');
define('TABLE_HEADING_ROWS','No');
define('TABLE_HEADING_ORDER_NUMBER','Order Number');
define('TABLE_HEADING_DATE','Date');
define('TABLE_HEADING_AMOUNT','Amount');
define('TABLE_HEADING_NAME','Card Name');
?>