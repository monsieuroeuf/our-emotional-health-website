<?php
/*
  $Id: stats_monthly_sales.php,v 1.5a $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Camtech Details');
define('HEADING_TITLE_ERROR','Error');
define('TABLE_HEADING_ROWS','Rows');
define('TABLE_HEADING_ORDER_NUMBER','Order Number');
define('TABLE_HEADING_SUMMARY','Error Summary');
define('TABLE_HEADING_DATE','Error Date');
define('TABLE_HEADING_AMOUNT','Error Amount');
define('TABLE_HEADING_CODE','Error Response Code');
define('TABLE_HEADING_MESSAGE','Error Message');

define('HEADING_TITLE_SUCCESS','Success');
define('TABLE_HEADING_NUMBER','Card Number'); 
define('TABLE_HEADING_EXPIRY','Card Expiry Date'); 
define('TABLE_HEADING_SUCCESS_DATE','Date');
define('TABLE_HEADING_SUCCESS_AMOUNT','Amount');
define('TABLE_HEADING_NAME','Cardholders Name'); 

define('TEXT_BACK_TO_REPORT','Back To Report');

?>