<?php

define('HEADING_TITLE', 'Administrators');

define('ERROR_PASSWORDS_DIFFERS', 'Passwords differs');
define('HEADING_ADMIN', 'Administrators');
define('HEADING_CHANGE_PASSWORD', 'Change Passwords');
define('HEADING_DELETE', 'delete');
define('ICON_INFO', 'Info');
define('HEADING_ACTION', 'action');
define('NEW_ADMIN', 'New admin');
define('MAKE_NEW_ADMIN', 'Create new administrator');
define('USERNAME', 'Username');
define('PASSWORD', 'Password');
define('REPEAT_PASSWORD', 'Repeat Password');
define('HEADING_TITLE', 'Administrator Control');
define('AUTHORIZE_DELETE', 'Delete administrator');
define('ARE_YOU_SURE_DELETE', 'Are you sure you want to delete this admin account');
define('AUTHORIZE_NEW_PASS', 'Change password');
define('INFO_CHANGE_PASSWORD', 'Change password');
define('INFO_USERNAME', 'Username:');
define('HEADING_INFO','Administrator info');
?>