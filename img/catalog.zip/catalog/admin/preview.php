<?
  require('includes/application_top.php');
include_once 'ez_sql.php';

$editNum = $_GET['ieditNum'];
$button02 = "#". $_GET['button02'];
$text_font = $_GET['text_font'];
$text_size = $_GET['text_size'];

//echo $editNum."<br>";
//echo "button2= ". $button02 . "<br>";
//echo $text_font . "<br>". $text_size;

//center shop details----------------------------------------------
$iQuery1 = " SELECT * FROM ". TABLE_CONFIGURATION . " WHERE configuration_id = 445 ";  //CENTER_SHOP_ON
$config1 = tep_db_query($iQuery1);
$r1 = mysql_fetch_row ($config1);
$isOn = $r1['3'];

$iQuery2 = " SELECT * FROM ". TABLE_CONFIGURATION . " WHERE configuration_id = 446 "; //CENTER_SHOP_ALIGN
$config2 = tep_db_query($iQuery2);
$r2 = mysql_fetch_row ($config2);
$iAlign = $r2['3'];

$iQuery3 = " SELECT * FROM ". TABLE_CONFIGURATION . " WHERE configuration_id = 447 "; //CENTER_SHOP_WIDTH
$config3 = tep_db_query($iQuery3);
$r3 = mysql_fetch_row ($config3);
$iWidth  = $r3['3'];

define('CENTER_SHOP_ON',$isOn); 

if (CENTER_SHOP_ON == '0'){
	define('CENTER_SHOP_WIDTH','100%');
	define('CENTER_SHOP_ALIGN','center');
} else {
	define('CENTER_SHOP_WIDTH',$iWidth); 
	define('CENTER_SHOP_ALIGN',$iAlign);
}

//eof center shop details-------------------------------------------

//Query the database for current css configurations and assign them to variables...
$iQuery="
	SELECT * 
	FROM  ".TABLE_CSS_CONFIG."
	WHERE config_id = 1
	";

$r = $db->get_row($iQuery);

$ibodyBg = $r->mainbodyBg;
$ibodyColor = $r->bodyColor;
$iaColor = $r->aColor;
$iaHoverColor = $r->aHoverColor;
$iboxTextFont = $r->boxTextFont;
$iboxTextSize = $r->boxTextSize;
$itrHeader = $r->trHeader;
$itrHeaderNavigation = $r->trHeaderNavigation;
$infoBoxBg= $r->infoBoxBg;
$infoBoxFont = $r->infoBoxFont;
$infoBoxSize = $r->infoBoxSize;
$itrFooterBg = $r->trFooterBg;
$ipgHeadingColor = $r->pgHeadingColor;
$ipgHeadingFont = $r->pgHeadingFont;
$ipgHeadingSize = $r->pgHeadingSize;
$infoBoxHBgColor = $r->infoBoxHBgColor;
$infoBoxBordColor = $r->infoBoxBordColor;
$infoBoxHColor = $r->infoBoxHColor;
$infoBoxHFont = $r->infoBoxHFont;
$infoBoxHSize = $r->infoBoxHSize;
//eof querying database

switch ($ieditNum) {  //assigning current values depending on what is being edited
	case "A1":{
		$ibodyBg = $button02;
		break;
	}
	case "A2":{
		$ibodyColor = $button02;
		break;
	}
	case "A3":{
		$iaColor = $button02;		
		break;
	}
	case "A4":{
		$iaHoverColor=$button02;
		break;
	}
	case "A5":{
		$itrHeader = $button02;
		break;
	}
	case "A6":{
		$itrHeaderNavigation = $button02;
		break;
	}
	case "A7":{
		$itrFooterBg= $button02;
		break;
	}
	case "A8":{
		$infoBoxHBgColor= $button02;
		break;
	}
	case "A9":{
		$infoBoxBordColor= $button02;
		break;
	}
	case "B1":{
		$iboxTextFont = $text_font;
		$iboxTextSize = $text_size;
	break;
	}
	case "C1":{
		$infoBoxBg = $button02;
		$infoBoxFont = $text_font;
		$infoBoxSize = $text_size;
		break;
	}
	case "C2":{
		$ipgHeadingColor = $button02;
		$ipgHeadingFont = $text_font;
		$ipgHeadingSize = $text_size;
		break;
	}
	case "C3":{
		$infoBoxHBgColor = $button02;
		$infoBoxHFont = $text_font;
		$infoBoxHSize = $text_size;
		break;
	}
}

$datenow = time(); //current date & time
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html";>
<title>Welcome to Ishop3</title>
<style type="text/css">
<!--
BODY {
  color: <?=$ibodyColor?>;
  margin: 0px 0px;
}
a:link { color: <?=$iaColor?>; text-decoration: none;}
a:hover { color: <?=$iaHoverColor?>; text-decoration: underline;}

.boxText { font-family: <?=$iboxTextFont?>; font-size: <?=$iboxTextSize?>; }

TR.header {
  background: <?=$itrHeader?>;
}

TD.infoBoxHeading {
  font-family: <?=$infoBoxHFont?>;
  font-size: <?=$infoBoxHSize?>;
  font-weight: bold;
  background: <?=$infoBoxHBgColor?>;
  color: <?=$infoBoxHColor?>;
}
.infoBox {
  background: <?=$infoBoxBordColor?>;
}

.infoBoxContents {
  background: <?=$infoBoxBg?>;
  font-family: <?=$infoBoxFont?>;
  font-size: <?=$infoBoxSize?>;
}

TD.footer {
  font-family: Verdana, Arial, sans-serif;
  font-size: 10px;
  background: <?=$itrFooterBg?>;
  color: #ffffff;
  font-weight: bold;
}
TD.headerNavigation {
  font-family: Verdana, Arial, sans-serif;
  font-size: 10px;
  background: <?=$itrHeaderNavigation?>;
  color: #ffffff;
  font-weight : bold;
}

.pageHeading {
  font-family: <?=$ipgHeadingFont?>;
  font-size: <?=$ipgHeadingSize?>;
  font-weight: bold;
  color: <?=$ipgHeadingColor?>;
}

A.headerNavigation:hover {
  color: #ffffff;
}
-->
</style>
</head>
<body bgcolor="<?=$ibodyBg?>">
<table border="0" width="<?echo CENTER_SHOP_WIDTH?>" cellspacing="0" cellpadding="0" align="<?echo CENTER_SHOP_ALIGN?>" valign="middle" bgcolor="<?=$itrHeader?>">
	<tr height="80">
		<td bgcolor="<?=$itrHeader?>" width="350">
			<img src="images/ilisys_logo.gif" border="0" alt="ilisys" title=" ilisys ">
		</td>
	</tr>
</table>
<?
if (CENTER_SHOP_ALIGN !=center){  
	echo '<br clear="'.CENTER_SHOP_ALIGN.'">'; //stops the tag from adding in additional lines
}
?>
<table border="0" width="<?echo CENTER_SHOP_WIDTH?>" cellspacing="0" cellpadding="0" align="<?echo CENTER_SHOP_ALIGN?>" valign="middle">
	<tr>
		<td>
			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr height="13">
					<td width="5" class="headerNavigation">
					</td>
					<td class="headerNavigation">
						<a href="#" class="headerNavigation">Top </a>>> <a href="#" class="headerNavigation">Catalog</a>
					</td>
					<td align="right" class="headerNavigation">
						<a href="#" class="headerNavigation" >My Account</a>  |  
						<a href="#" class="headerNavigation">Cart Contents</a>  |  
						<a href="#" class="headerNavigation">Checkout</a>   
					</td>
					<td width="5" class="headerNavigation">
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<?
if (CENTER_SHOP_ALIGN !=center){  
	echo '<br clear="'.CENTER_SHOP_ALIGN.'">'; //stops the tag from adding in additional lines
} else {
	echo '<br>';
}
?>
<table border="0" width="<?echo CENTER_SHOP_WIDTH?>" cellspacing="0" cellpadding="0" align="<?echo CENTER_SHOP_ALIGN?>" valign="middle">
	<tr>
		<td width="5">
		</td>
		<td width="110">
			<table border="1" width="125" cellspacing="0" cellpadding="4" borderColor="<?=$ibodyBg?>">
			  <tr height="20" class="infoBox" borderColor="<?=$infoBoxHBgColor?>">
			  	<td class="infoBoxHeading">
			  		Categories
			  	</td>
			  </tr>
			  <tr height="60" class="infoBoxContents" borderColor="<?=$infoBoxBordColor?>">
			  	<td class="boxText">
					<a href="#">Category 1<br></a>
					<a href="#">Category 2<br></a>
					<a href="#">Category 3<br></a>
					<a href="#">Category 4<br></a>
				</td>
			  </tr>
			</table>
		</td>
		<td width="5%">
		</td>
		<td align="left" width="60%">
			<FONT class="pageHeading">iShop3 - iLisys</FONT><br>
			<FONT face="Arial" size="1" align="left">Welcome Guest! Would you like to log yourself in? Or would 
			you prefer to create an account?<br><br></font>
			<FONT face="Arial" size="2" align="left" color="black">This is an approximate preview of the current 
			change you made
			This is . To save these changes, hit Save Changes in the 
			CSS Editor</font>
		</td>
		<td width="10%">
		</td>
		<td>
			<table border="1" width="125" cellspacing="0" cellpadding="4" borderColor="<?=$ibodyBg?>">
			  <tr height="20" class="infoBox" borderColor="<?=$infoBoxHBgColor?>">
			  	<td class="infoBoxHeading">
			  		Cart
			  	</td>
			  </tr>
			  <tr height="30" class="infoBoxContents"  borderColor="<?=$infoBoxBordColor?>">
			  	<td class="boxText">
					0 Items<br>
				</td>
			  </tr>
			</table>
			<br>
		</td>
	</tr>
</table>
<?
if (CENTER_SHOP_ALIGN !=center){  
	echo '<br clear="'.CENTER_SHOP_ALIGN.'">'; //stops the tag from adding in additional lines
}
?>
<table border="0" width="<?echo CENTER_SHOP_WIDTH?>" cellspacing="0" cellpadding="0" align="<?echo CENTER_SHOP_ALIGN?>" valign="middle">
	<tr>
		<td width="5">
		</td>
		<td>
			<table border="1" width="125" cellspacing="0" cellpadding="4" borderColor="<?=$ibodyBg?>">
			  <tr height="20" class="infoBox" borderColor="<?=$infoBoxHBgColor?>"> 
			  	<td class="infoBoxHeading">
			  		Whats New
			  	</td>
			  </tr>
			  <tr height="90" class="infoBoxContents" borderColor="<?=$infoBoxBordColor?>">
			  	<td class="boxText">
					<a href="#">New Item 1<br></a>
				</td>
			  </tr>
			</table>
		</td>
		<td width = "10">
		</td>
		<?
		$iwidth=10;
		if ($iwidth == 100){ //show the New products only if width is 100%
		?>
			<td>
				<table border="1" width="100%" cellspacing="0" cellpadding="4" borderColor="<?=$ibodyBg?>">
				  <tr height="20" class="infoBox" borderColor="<?=$infoBoxHBgColor?>"> 
				  	<td class="infoBoxHeading">
				  		New Products for January
				  	</td>
				  </tr>
				  <tr height="120" class="infoBoxContents" borderColor="<?=$infoBoxBordColor?>">
				  	<td class="boxText">
						<table border="0"   width="330" cellspacing="0" cellpadding="0">
							<tr class="infoBoxContents">
								<td width="15">
								</td>
								<td>
									<a href="#">Product 1<br><br></a>
									<a href="#">Product 2<br><br></a>
									<a href="#">Product 3<br><br></a>
								</td>
								<td width="40">
								</td>
								<td>
									<a href="#">Product 4<br><br></a>
									<a href="#">Product 5<br><br></a>
									<a href="#">Product 6<br><br></a>
								<td width="40">
								</td>
								<td>
									<a href="#">Product 7<br><br></a>
									<a href="#">Product 8<br><br></a>
									<a href="#">Product 9<br><br></a>
								</td>
							</tr>
						</table>
					</td>
				  </tr>
				</table>
			</td>
		<?
		} else {
		?>
			<td width="50%"></td>
		<?
		}
		?>
		<td width="20%">
		</td>
		<td>
			<table border="1" width="125" cellspacing="0" cellpadding="4" borderColor="<?=$ibodyBg?>">
			  <tr height="20" class="infoBox" borderColor="<?=$infoBoxHBgColor?>"> 
			  	<td class="infoBoxHeading">Bestsellers</td>
			  </tr>
			  <tr height="30" class="infoBoxContents" borderColor="<?=$infoBoxBordColor?>">
			  	<td class="boxText">
					<a href="#">Bestseller 1</a><br>
					<a href="#">Bestseller 2</a><br>
				</td>
			  </tr>
			</table>
			<br>
			<br>
			<br>
			<br>
			<br>
		</td>
	</tr>
</table>
<?
if (CENTER_SHOP_ALIGN !=center){  
	echo '<br clear="'.CENTER_SHOP_ALIGN.'">'; //stops the tag from adding in additional lines
} else {
	echo '<br><br><br>';
}
?>

<table border="0" width="<?echo CENTER_SHOP_WIDTH?>" cellspacing="0" cellpadding="0" align="<?echo CENTER_SHOP_ALIGN?>" valign="middle">
	<tr>
		<td>
			<table border="0" width="100%" cellspacing="0" cellpadding="0" bgcolor="<?=$itrFooterBg?>">
				<tr height="13">
					<td width="5" class="footer"></td>
					<td class="footer"><?echo date("l d F, Y",$datenow);?></td>
					<td align="right" class="footer">1215 requests since Tuesday 16 September, 2003  </td>
					<td width="5" class="footer"></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<?
if (CENTER_SHOP_ALIGN !=center){  
	echo '<br clear="'.CENTER_SHOP_ALIGN.'">'; //stops the tag from adding in additional lines
} else {
	echo '<br>';
}
?>
<table border="0" width="<?echo CENTER_SHOP_WIDTH?>" cellspacing="0" cellpadding="0" align="<?echo CENTER_SHOP_ALIGN?>" valign="middle">
	<tr height="40">
		<td align = "center"><FONT face="Arial" size="1">Powered by osCommerce</font></td>
	</tr>
</table>
