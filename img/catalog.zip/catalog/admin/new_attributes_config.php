<?

// Change to your default language ID if it differs.
  $languageFilter = "1";
  
// If you have Options Type Feature ver. 2.02.MS1 by countezero installed - make this = "1"
  $optionTypeInstalled = "0";
  
// If you have "Attributes Sorter & Copier v5.1 with weight" 
// by Linda McGrath installed - make this = "1"
  $optionSortCopyInstalled = "0";

// If you have Option Type Feature v-1.4 by Chandra Roukema installed - make this = "1"
  $optionTypeTextInstalled = "0";
// If you have Option Type Feature v-1.4 by Chandra Roukema installed - set this to your
// PRODUCTS_OPTIONS_VALUE_TEXT_ID value ( usually "0" )
  $optionTypeTextInstalledID = "0";
  
?>
