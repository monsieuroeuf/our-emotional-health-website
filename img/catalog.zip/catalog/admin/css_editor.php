<?php
/*
  css editor for osCommerce storefront
  maintained by: Bobby Patel
*/

  require('includes/application_top.php');

  require(DIR_WS_CLASSES . 'currencies.php');
  $currencies = new currencies();
  
  include_once 'ez_sql.php';

//variables:
$itmpStylesheet = "../tmpstylesheet.css";  //temporary stylesheet file
$itmpSheetcontent = ""; //css content
$icurrentStyle = "../stylesheet.css";  //current stylesheet


//implode the temporary stylesheet contents.
$itmpSheetcontent = implode("",file($itmpStylesheet));

if (isset($_GET['editType'])){ 			// which category is being edited
	$ieditType = $_GET['editType'];
} else {
	$ieditType = "A"; //default to color management
}


if (isset($_GET['editNum'])){ 			// the specific edit has been picked
	$ieditNum = $_GET['editNum'];
} else { // use default
	$ieditNum = "A1"; //default to main body bg
}

				 
//if changes were submitted---------------------------------------------------
if (isset($_POST['change'])){ 
  	if ($_POST['change']== "change"){ //each case generates a specific query for the database.
		switch ($ieditNum) {
			case "A1":{
				$iQuery="
					UPDATE
						".TABLE_CSS_CONFIG."
					SET
						mainbodyBg = '". $_POST['button02'] ."'
					WHERE
						config_id=1
					";
				break;
			}
			case "A2":{
				$iQuery="
					UPDATE
						".TABLE_CSS_CONFIG."
					SET
						bodyColor = '". $_POST['button02'] ."'		
					WHERE
						config_id=1
					";
				break;
			}
			case "A3":{
				$iQuery="
					UPDATE
						".TABLE_CSS_CONFIG."
					SET
						aColor = '". $_POST['button02'] ."'
					WHERE
						config_id=1
					";
				break;
			}
			case "A4":{
				$iQuery="
					UPDATE
						".TABLE_CSS_CONFIG."
					SET
						aHoverColor = '". $_POST['button02'] ."'
					WHERE
						config_id=1
					";
				break;
			}
			case "A5":{
				$iQuery="
					UPDATE
						".TABLE_CSS_CONFIG."
					SET
						trHeader = '". $_POST['button02'] ."'
					WHERE
						config_id=1
					";
				break;
			}
			case "A6":{
				$iQuery="
					UPDATE
						".TABLE_CSS_CONFIG."
					SET
						trHeaderNavigation = '". $_POST['button02'] ."'
					WHERE
						config_id=1
					";
				break;
			}
			case "A7":{
				$iQuery="
					UPDATE
						".TABLE_CSS_CONFIG."
					SET
						trFooterBg = '". $_POST['button02'] ."'
					WHERE
						config_id=1
					";
				break;
			}
			case "A8":{
				$iQuery="
					UPDATE
						".TABLE_CSS_CONFIG."
					SET
						infoBoxHBgColor = '". $_POST['button02'] ."'
					WHERE
						config_id=1
					";
				break;
			}
			case "A9":{
				$iQuery="
					UPDATE
						".TABLE_CSS_CONFIG."
					SET
						infoBoxBordColor = '". $_POST['button02'] ."'
					WHERE
						config_id=1
					";
				break;
			}
			case "B1":{
				$iQuery="
					UPDATE
						".TABLE_CSS_CONFIG."
					SET
						boxTextSize = '". $_POST['text_size'] ."',
						boxTextFont = '". $_POST['text_style'] ."'
					WHERE
						config_id=1
					";
				break;
			}
			case "C1":{
				$iQuery="
					UPDATE
						".TABLE_CSS_CONFIG."
					SET
						infoBoxBg = '". $_POST['button02'] ."',
						infoBoxFont = '". $_POST['text_style'] ."',
						infoBoxSize = '". $_POST['text_size'] ."'
					WHERE
						config_id=1
					";
				break;
			}
			case "C2":{
				$iQuery="
					UPDATE
						".TABLE_CSS_CONFIG."
					SET
						pgHeadingColor = '". $_POST['button02'] ."',
						pgHeadingFont = '". $_POST['text_style'] ."',
						pgHeadingSize = '". $_POST['text_size'] ."'
					WHERE
						config_id=1
					";
				break;
			}
			case "C3":{
				$iQuery="
					UPDATE
						".TABLE_CSS_CONFIG."
					SET
						infoBoxHColor = '". $_POST['button02'] ."',
						infoBoxHFont = '". $_POST['text_style'] ."',
						infoBoxHSize = '". $_POST['text_size'] ."'
					WHERE
						config_id=1
					";
				break;
			}
		}
		$iupdate = $db->Query($iQuery); // execute the given query
	}
}//--eof if changes were submitted--------------------

//Query the database for current css configurations and assign them to variables...
$iQuery="
	SELECT * 
	FROM  ".TABLE_CSS_CONFIG." 
	WHERE config_id = 1
	";

$r = $db->get_row($iQuery); //execute the query above
//assign values as per entries in the database
$ibodyBg = $r->mainbodyBg;
$ibodyColor = $r->bodyColor;
$iaColor = $r->aColor;
$iaHoverColor = $r->aHoverColor;
$iboxTextFont = $r->boxTextFont;
$iboxTextSize = $r->boxTextSize;
$itrHeader = $r->trHeader;
$itrHeaderNavigation = $r->trHeaderNavigation;
$infoBoxBg= $r->infoBoxBg;
$infoBoxFont = $r->infoBoxFont;
$infoBoxSize = $r->infoBoxSize;
$itrFooterBg = $r->trFooterBg;
$ipgHeadingColor = $r->pgHeadingColor;
$ipgHeadingFont = $r->pgHeadingFont;
$ipgHeadingSize = $r->pgHeadingSize;
$infoBoxHBgColor = $r->infoBoxHBgColor;
$infoBoxBordColor = $r->infoBoxBordColor;
$infoBoxHColor = $r->infoBoxHColor;
$infoBoxHFont = $r->infoBoxHFont;
$infoBoxHSize = $r->infoBoxHSize;
//eof querying database

switch ($ieditNum) {  //assigning current values depending on what is being edited
	case "A1":{
		$ibutton2val = $ibodyBg;
		$iMsg = "Main Body Background";
		$dispA1='<font color="red"><< </font>';
		break;
	}
	case "A2":{
		$ibutton2val = $ibodyColor;
		$iMsg = "Body Text Color";
		$dispA2='<font color="red"><< </font>';
		break;
	}
	case "A3":{
		$ibutton2val = $iaColor;		
		$iMsg = "A: Color";
		$dispA3='<font color="red"><< </font>';
		break;
	}
	case "A4":{
		$ibutton2val = $iaHoverColor;
		$iMsg = "A: Hover Color";
		$dispA4='<font color="red"><< </font>';
		break;
	}
	case "A5":{
		$ibutton2val = $itrHeader;
		$iMsg = "TR:Header";
		$dispA5='<font color="red"><< </font>';
		break;
	}
	case "A6":{
		$ibutton2val = $itrHeaderNavigation;
		$iMsg = "TR:Header Navigation";
		$dispA6='<font color="red"><< </font>';
		break;
	}
	case "A7":{
		$ibutton2val = $itrFooterBg;
		$iMsg = "TR:Footer";
		$dispA7='<font color="red"><< </font>';
		break;
	}
	case "A8":{
		$ibutton2val = $infoBoxHBgColor;
		$iMsg = "TD:InfoBoxHeadingBgColor";
		$dispA8='<font color="red"><< </font>';
		break;
	}
	case "A9":{
		$ibutton2val = $infoBoxBordColor;
		$iMsg = "TD:InfoBoxBg";
		$dispA9='<font color="red"><< </font>';
		break;
	}
	case "B1":{
		$iboxFontval = $iboxTextFont;
		$iboxSizeval = $iboxTextSize;
		$iMsg = ".Box Style";
		$dispB1='<font color="red"><< </font>';
	break;
	}
	case "C1":{
		$ibutton2val = $infoBoxBg;
		$iboxFontval = $infoBoxFont;
		$iboxSizeval = $infoBoxSize;
		$iMsg = "infoBoxContents";
		$dispC1='<font color="red"><< </font>';
	break;
	}
	case "C2":{
		$ibutton2val = $ipgHeadingColor;
		$iboxFontval = $ipgHeadingFont;
		$iboxSizeval = $ipgHeadingSize;
		$iMsg = "Page Heading";
		$dispC2='<font color="red"><< </font>';
		break;
	}
	case "C3":{
		$ibutton2val = $infoBoxHColor;
		$iboxFontval = $infoBoxHFont;
		$iboxSizeval = $infoBoxHSize;
		$iMsg = "Box Heading";
		$dispC3='<font color="red"><< </font>';
		break;
	}
	echo $ibutton2val;
}

if (isset($_POST['change'])){ //different from previous if-change above, this is to replace values and write new stylesheet file
  	if ($_POST['change']== "change"){
		// first check to see if there is a pending function waiting for writing the stylesheet
		$iQueryCheck = "
					SELECT 
						function_id,
						function_cmd,
						function_run
					FROM	
						".TABLE_PENDING_FUNCTIONS."
					WHERE
						function_run='0'
					AND
						function_cmd='write_style'
		";
		$iCheck = $db->Query($iQueryCheck);
		if ($iCheck) {
			//there is a waiting pending function, update it instead of adding a new one
			$pfQuery ="   
			    UPDATE ".TABLE_PENDING_FUNCTIONS."
				SET
					function_run_at        = DATE_ADD(now(), INTERVAL 2 MINUTE),
					function_priority	   ='10',
					function_added_by	   ='webAdmin',
					function_cmd		   ='write_style',
					function_catalog_path  ='" . DIR_WS_CATALOG. "',
					function_admin_path    ='" . DIR_WS_ADMIN. "',
					function_run		   ='0'
				WHERE
					function_run='0'
				AND
					function_cmd='write_style'
			";
		} else {
			//theres no waiting pending function for write_style so insert a new one
			$pfQuery ="   
			    INSERT INTO ".TABLE_PENDING_FUNCTIONS."
				(
					function_run_at,
					function_priority,
					function_added_by,
					function_cmd,
					function_catalog_path,
					function_admin_path,
					function_run
				)
				VALUES
				(
					DATE_ADD(now(), INTERVAL 2 MINUTE),
					'10',
					'webAdmin',
					'write_style',
					'" . DIR_WS_CATALOG. "',
					'" . DIR_WS_ADMIN. "',
					'0'
				)
			";
		}
		
		$pfunction = $db->Query($pfQuery);
		$iSuccesswrite = "-- New Pending Funtion Added -- <br>";
		$iSuccesswrite .= "-- Any changes can take upto 10mins to show in the catalog --<br>";
	}
}

//to select the current options in the drop down lists.
$iTextSizes= array(3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20);
$iTextFont=array("MS Sans Serif, Microsoft Sans Serif", 
				 "Angsana New, AngsanaUPC",
				 "Browallia New, BrowalliaUPC", 
				 "Cordia New, CordiaUPC",
				 "Arial, Helvetica, sans-serif",
				 "Times New Roman, Times, serif", 
				 "Courier New, Courier, mono",
				 "Georgia, Times New Roman, Times, serif", 
				 "Verdana, Arial, MS Sans Serif");


for ($i=0;$i<sizeof($iTextSizes);$i++) {
	if ($iboxSizeval == $iTextSizes[$i]){ 
		$iSizeOptions[$i] = '<option value="'.$iTextSizes[$i].'" selected>'.$iTextSizes[$i].'</option>';
	}else{
		$iSizeOptions[$i] = '<option value="'.$iTextSizes[$i].'">'.$iTextSizes[$i].'</option>';
	}
}

for ($i=0;$i<sizeof($iTextFont);$i++) {
	if ($iboxFontval == $iTextFont[$i]){ 
		$iFontOptions[$i] = '<option value="'.$iTextFont[$i] .'"selected>'.$iTextFont[$i] .'</option>';
	}else{
		$iFontOptions[$i] = '<option value="'.$iTextFont[$i] .'">'.$iTextFont[$i] .'</option>';
	}
}

?>
<!doctype html public "-//W3C//DTD HTML 4.01 Transitional//EN">
<html <?php echo HTML_PARAMS; ?>>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo CHARSET; ?>">
<title><?php echo TITLE; ?></title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
<script language="javascript" src="includes/general.js"></script>
<script language="javascript">
<!--
var color;

function getColor(color){
	color=document.color2.button02.value;
	document.color2.submit();
}

function preview(color){
	<?
	if ($ieditType == "A"){
	?>
		color=document.color2.button02.value;
		URLlink="preview.php?&ieditNum=<?=$ieditNum?>&button02=" + color.substr(1,9);
	<?
	}else if ($ieditType == "B"){
	?>
		URLlink="preview.php?&ieditNum=<?=$ieditNum?>&text_size=" + document.color2.text_size.value + "&text_font=" + document.color2.text_style.value;
	<?
	}else if ($ieditType == "C"){
	?>
		color=document.color2.button02.value;
		URLlink="preview.php?&ieditNum=<?=$ieditNum?>&button02=" + color.substr(1,9)+ "&text_size=" + document.color2.text_size.value + "&text_font=" + document.color2.text_style.value;
	<?
	}
	?>
	window1=window.open(URLlink,'messageWindow1','scrollbars=yes,width=950,height=500')
	window1.focus();
}
//-->
</script>
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?php require(DIR_WS_INCLUDES . 'header.php'); ?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="2" cellpadding="2">
  <tr>
    <td width="<?php echo BOX_WIDTH; ?>" valign="top"><table border="0" width="<?php echo BOX_WIDTH; ?>" cellspacing="1" cellpadding="1" class="columnLeft">
<!-- left_navigation //-->
<?php require(DIR_WS_INCLUDES . 'column_left.php'); ?>
<!-- left_navigation_eof //-->
    </table></td>
<!-- body_text //-->
	<td width="10"></td>
	<form name="color2" action="<?=HTTP_SERVER.DIR_WS_ADMIN?>css_editor.php?editType=<?=$ieditType?>&editNum=<?=$ieditNum?>" method="post">
	<Td valign="top" class="pageHeading" width="50%">
		<font size="2px">
			<b>
				CSS Editor.<br><br>
				<font color="blue" class = "smallText"><?echo $iMsg. "<br>"?></font>
				<font color="red" class = "smallText"><?echo $iSuccess?></font>
				<font color="red" class = "smallText"><?echo $iSuccesswrite?></font>				
			</b>
		</font>
		<br>
		
		<table border="0" width="67%" cellspacing="0" cellpadding="0">
			
			<br>
			<? if ($ieditType == "A" || $editType =="C"){?>
				<font class="smallText">
					HEX Color: <input type="text" name="button02" value="<?=$ibutton2val?>" maxlength="7" SIZE=8 >
				</font>
				
				<!-- ************************THE TABLE FOR COLORS AND RADIO BUTTONS****************************** //-->
		        <tr> 
		            <td  bgColor=ceffff>&nbsp;</td>
		            <td  bgColor=9ccfff>&nbsp;</td>
		            <td  bgColor=66cccc>&nbsp;</td>
		            <td  bgColor=3399cc>&nbsp;</td>
		            <td  bgColor=0000ff>&nbsp;</td>
		            <td  bgColor=003399>&nbsp;</td>
		            <td  bgColor=ffccff>&nbsp;</td>
		            <td  bgColor=ff9aff>&nbsp;</td>
		            <td  bgColor=cc66cc>&nbsp;</td>
		            <td  bgColor=cc33cc>&nbsp;</td>
		            <td  bgColor=993399>&nbsp;</td>
		            <td  bgColor=840084>&nbsp;</td>
		        </tr>
		        <tr> 
		            <td>
		                <input type=radio name="button01" value="#ceffff" onClick="document.color2.button02.value='#ceffff';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#9ccfff" onClick="document.color2.button02.value='#9ccfff';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#66cccc" onClick="document.color2.button02.value='#66cccc';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#3399cc" onClick="document.color2.button02.value='#3399cc';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#0000ff" onClick="document.color2.button02.value='#0000ff';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#003399" onClick="document.color2.button02.value='#003399';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#ffccff" onClick="document.color2.button02.value='#ffccff';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#ff9aff" onClick="document.color2.button02.value='#ff9aff';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#cc66cc" onClick="document.color2.button02.value='#cc66cc';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#cc33cc" onClick="document.color2.button02.value='#cc33cc';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#993399" onClick="document.color2.button02.value='#993399';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#840084" onClick="document.color2.button02.value='#840084';" >
		            </td>
		        </tr>
		        <tr> 
		            <td bgColor=ffcfce>&nbsp;</td>
		            <td bgColor=ff6666>&nbsp;</td>
		            <td bgColor=ff0000>&nbsp;</td>
		            <td bgColor=cc3333>&nbsp;</td>
		            <td bgColor=990000>&nbsp;</td>
		            <td bgColor=660033>&nbsp;</td>
		            <td bgColor=ffffce>&nbsp;</td>
		            <td bgColor=ffff9c>&nbsp;</td>
		            <td bgColor=ffff00>&nbsp;</td>
		            <td bgColor=cccc66>&nbsp;</td>
		            <td bgColor=999933>&nbsp;</td>
		            <td bgColor=666633>&nbsp;</td>
		        </tr>
		        <tr> 
		            <td> 
		                <input type=radio name="button01" value="#ffcfce" onClick="document.color2.button02.value='#ffcfce';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#ff6666" onClick="document.color2.button02.value='#ff6666';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#ff0000" onClick="document.color2.button02.value='#ff0000';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#cc3333" onClick="document.color2.button02.value='#cc3333';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#990000" onClick="document.color2.button02.value='#990000';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#660033" onClick="document.color2.button02.value='#660033';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#ffffce" onClick="document.color2.button02.value='#ffffce';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#ffff9c" onClick="document.color2.button02.value='#ffff9c';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#ffff00" onClick="document.color2.button02.value='#ffff00';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#cccc66" onClick="document.color2.button02.value='#cccc66';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#999933" onClick="document.color2.button02.value='#999933';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#666633" onClick="document.color2.button02.value='#666633';" >
		            </td>
		        </tr>
		        <tr> 
		            <td bgColor=cfffce>&nbsp;</td>
		            <td bgColor=66ff66>&nbsp;</td>
		            <td bgColor=00ff00>&nbsp;</td>
		            <td bgColor=33cc33>&nbsp;</td>
		            <td bgColor=009900>&nbsp;</td>
		            <td bgColor=006633>&nbsp;</td>
		            <td bgColor=ffffff>&nbsp;</td>
		            <td bgColor=cccccc>&nbsp;</td>
		            <td bgColor=999999>&nbsp;</td>
		            <td bgColor=666666>&nbsp;</td>
		            <td bgColor=333333>&nbsp;</td>
		            <td bgColor=000000>&nbsp;</td>
		        </tr>
		        <tr> 
		            <td> 
		                <input type=radio name="button01" value="#cfffce" onClick="document.color2.button02.value='#cfffce';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#66ff66" onClick="document.color2.button02.value='#66ff66';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#00ff00" onClick="document.color2.button02.value='#00ff00';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#33cc33" onClick="document.color2.button02.value='#33cc33';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#009900" onClick="document.color2.button02.value='#009900';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#006633" onClick="document.color2.button02.value='#006633';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#ffffff" onClick="document.color2.button02.value='#ffffff';">
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#cccccc" onClick="document.color2.button02.value='#cccccc';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#999999" onClick="document.color2.button02.value='#999999';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#666666" onClick="document.color2.button02.value='#666666';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#333333" onClick="document.color2.button02.value='#333333';" >
		            </td>
		            <td> 
		                <input type=radio name="button01" value="#000000" onClick="document.color2.button02.value='#000000';" >
		            </td>
		        </tr>
			</table>
		<!-- ***************************************************************************************************** //-->        
	        	
				<table width=230 cellpadding=1 cellspacing=0 border=0>
					<tr>
						<td class= "smallText"><b>old value:</b></td>
						<td class= "smallText" align="left">
							<table bgcolor="#000000" width=20>
									<td bgcolor="<?=$ibutton2val?>" align="left">
										&nbsp;
									</td>
							</table>
						</td>
					</tr>
				</table>
			<?
			}
			?>        
			<br>
			<? if ($ieditType == "B" || $editType== "C"){?>
				<table width="100%" cellpadding=2 cellspacing=2 border=0>
					<tr>
						<td width="90" class="smallText">Choose New Text Style:</td>
						<td align=left>
							<select name="text_style">
								<?
								for ($i = 0; $i < sizeof($iFontOptions); $i++) {
									echo $iFontOptions[$i] . "<br>";
								}
								?>
							</select>
						</td>
					</tr>
					<tr>
						<td width=100 class="smallText"> Choose New Text Size:</td>
						<td align=left>
							<select name="text_size">
								<?
								for ($i = 0; $i<sizeof($iSizeOptions); $i++) {
									echo $iSizeOptions[$i]."<br>";
								}
								?>
							</select>
						</td>
					</tr>
				</table>
				<?
				}
				?>
					<br>
					<table width="100%" cellpadding=2 cellspacing=2 border=0>
						<tr>
							<td width="238">
								<input type=hidden name ="change" value="change">
								<input type=submit value="Save changes" style="COLOR: #000000; BACKGROUND: #F5F5F5; FONT-FAMILY: Verdana; FONT-SIZE: 8pt; WIDTH: 120px;">
							</td>
							<td>			
								<input type=button value="Preview change" onClick="preview(color);" style="COLOR: #000000; BACKGROUND: #F5F5F5; FONT-FAMILY: Verdana; FONT-SIZE: 8pt; WIDTH: 120px;">
								</form>
							</td>
						</tr>
					</table>
			<td width =50></td>
			<td valign = "top" width="300">
				
				<table width="100%" cellpadding=2 cellspacing=1 border=0>
					 <tr class="dataTableHeadingRow">
						<td class="dataTableHeadingContent">Colour Management</td>
					 </tr>
				</table>
				<table width="100%" cellpadding=1 cellspacing=1 border=0>
					 <tr class="dataTableRow" onmouseover="rowOverEffect(this)" onmouseout="rowOutEffect(this)" onclick="document.location.href='<?php echo tep_href_link(FILENAME_CSS_EDITOR, 'editType=A&editNum=A1');?>'">
						
						<td class="dataTableContent">
							<?echo $dispA1?>Main Background Color<?echo $dispA1?>
						</td>
					 </tr>
					 <tr class="dataTableRow" onmouseover="rowOverEffect(this)" onmouseout="rowOutEffect(this)" onclick="document.location.href='<?php echo tep_href_link(FILENAME_CSS_EDITOR, 'editType=A&editNum=A2');?>'">
						<td class="dataTableContent">
							<?echo $dispA2?>Main Text Color<?echo $dispA2?>
						</td>
					 </tr>
					<tr class="dataTableRow" onmouseover="rowOverEffect(this)" onmouseout="rowOutEffect(this)" onclick="document.location.href='<?php echo tep_href_link(FILENAME_CSS_EDITOR, 'editType=A&editNum=A3');?>'">
						<td class="dataTableContent">
							<?echo $dispA3?>Link Color<?echo $dispA3?>
						</td>
					 </tr>
					<tr class="dataTableRow" onmouseover="rowOverEffect(this)" onmouseout="rowOutEffect(this)" onclick="document.location.href='<?php echo tep_href_link(FILENAME_CSS_EDITOR, 'editType=A&editNum=A4');?>'">
						<td class="dataTableContent">
							<?echo $dispA4?>Link Hover Color <?echo $dispA4?>
						</td>
					 </tr>
					<tr class="dataTableRow" onmouseover="rowOverEffect(this)" onmouseout="rowOutEffect(this)" onclick="document.location.href='<?php echo tep_href_link(FILENAME_CSS_EDITOR, 'editType=A&editNum=A5');?>'">
						<td class="dataTableContent">
							<?echo $dispA5?>Header Colour<?echo $dispA5?>
						</td>
					 </tr>
					<tr class="dataTableRow" onmouseover="rowOverEffect(this)" onmouseout="rowOutEffect(this)" onclick="document.location.href='<?php echo tep_href_link(FILENAME_CSS_EDITOR, 'editType=A&editNum=A6');?>'">
						<td class="dataTableContent">
							<?echo $dispA6?>Header Navigation Colour<?echo $dispA6?>
						</td>
					 </tr>
					<tr class="dataTableRow" onmouseover="rowOverEffect(this)" onmouseout="rowOutEffect(this)" onclick="document.location.href='<?php echo tep_href_link(FILENAME_CSS_EDITOR, 'editType=A&editNum=A7');?>'">
						<td class="dataTableContent">
							<?echo $dispA7?>Statistics Footer Colour<?echo $dispA7?>
						</td>
					 </tr>
					<tr class="dataTableRow" onmouseover="rowOverEffect(this)" onmouseout="rowOutEffect(this)" onclick="document.location.href='<?php echo tep_href_link(FILENAME_CSS_EDITOR, 'editType=A&editNum=A8');?>'">
						<td class="dataTableContent">
							<?echo $dispA8?>Box Heading Background Color<?echo $dispA8?>
						</td>
					 </tr>
					<tr class="dataTableRow" onmouseover="rowOverEffect(this)" onmouseout="rowOutEffect(this)" onclick="document.location.href='<?php echo tep_href_link(FILENAME_CSS_EDITOR, 'editType=A&editNum=A9');?>'">
						<td class="dataTableContent">
							<?echo $dispA9?>Box Border Color<?echo $dispA9?> 
						</td>
					</tr>
					<tr height="20"><td></td></tr>
				</table>
				<table width="100%" cellpadding=2 cellspacing=1 border=0>
					<tr class="dataTableHeadingRow">
						<td class="dataTableHeadingContent">Text Only</td>
					</tr>
				</table>
				<table width="100%" cellpadding=1 cellspacing=1 border=0>
					<tr class="dataTableRow" onmouseover="rowOverEffect(this)" onmouseout="rowOutEffect(this)" onclick="document.location.href='<?php echo tep_href_link(FILENAME_CSS_EDITOR, 'editType=B&editNum=B1');?>'">
						<td class="dataTableContent">
							<?echo $dispB1?>Columns Box Text<?echo $dispB1?>
						</td>
					</tr>
					<tr height="20"><td></td></tr>
				</table>
				<table width="100%" cellpadding=2 cellspacing=1 border=0>
					<tr class="dataTableHeadingRow">
						<td class="dataTableHeadingContent">Text And Colours</td>
					</tr>
				</table>
				<table width="100%" cellpadding=1 cellspacing=1 border=0>
					<tr class="dataTableRow" onmouseover="rowOverEffect(this)" onmouseout="rowOutEffect(this)" onclick="document.location.href='<?php echo tep_href_link(FILENAME_CSS_EDITOR, 'editType=C&editNum=C1');?>'">
						<td class="dataTableContent">
							<?echo $dispC1?>New Products Text & General Box Background<?echo $dispC1?>
						</td>
					</tr>				
					<tr class="dataTableRow" onmouseover="rowOverEffect(this)" onmouseout="rowOutEffect(this)" onclick="document.location.href='<?php echo tep_href_link(FILENAME_CSS_EDITOR, 'editType=C&editNum=C2');?>'">
						<td class="dataTableContent">
							<?echo $dispC2?>Page Heading Text & Color<?echo $dispC2?>
						</td>
					</tr>				
					<tr class="dataTableRow" onmouseover="rowOverEffect(this)" onmouseout="rowOutEffect(this)" onclick="document.location.href='<?php echo tep_href_link(FILENAME_CSS_EDITOR, 'editType=C&editNum=C3');?>'">
						<td class="dataTableContent">
							<?echo $dispC3?>Box Heading Text & Color<?echo $dispC3?> 
						</td>
					</tr>
				</table>
			</td>
			<td width=200 align="left"></td>
		</table>
	</td>
<!-- body_text_eof //-->
  </tr>
</table>
<!-- body_eof //-->
<br>
<!-- footer //-->
<?php require(DIR_WS_INCLUDES . 'footer.php'); ?>
<!-- footer_eof //-->
<br>
</body>
</html>
<?php require(DIR_WS_INCLUDES . 'application_bottom.php'); ?>
